function jugarTresEnRaya() {
    window.location.href = "raya.html";
}

function jugarDinosaurio() {
    window.location.href = "dino.html";
}


