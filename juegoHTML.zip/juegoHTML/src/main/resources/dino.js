document.addEventListener("DOMContentLoaded", function() {
    const usernameForm = document.getElementById("usernameForm");

    usernameForm.addEventListener("submit", function(event) {
        event.preventDefault(); // Evitar el envío del formulario por defecto

        const usernameInput = document.getElementById("username");
        const username = usernameInput.value.trim();

        if (username !== "") {
            // Guardar el nombre de usuario en localStorage
            localStorage.setItem("username", username);

            // Redirigir al juego
            window.location.href = "game.html"; // Reemplaza "game.html" con el nombre de tu archivo de juego
        } else {
            alert("Please enter your username."); // Alerta si el campo de nombre de usuario está vacío
        }
    });


});